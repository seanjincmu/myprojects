# Updated Animation Starter Code

from tkinter import *
#tkinter framework taken from 15-112 website

from playerClass import *
import random
import math
################################################################################
# customize these functions
################################################################################

def abs(x):
    if x>=0:
        return x
    else:
        return -x

####################################

def init(data):
    startMethod(data)
    playerInt(data)
    data.player1 = None
    data.player2 = None
    data.stage = PhotoImage(file = "backGrounds/background_game.gif")
    data.backGround = PhotoImage(file = "backGrounds/backgroundRest.gif")
    data.pImages = [PhotoImage(file = "characterSprites/dhCharGifs/alert_0.gif"), PhotoImage(
                    file= "characterSprites/daCharGifs/alert_0.gif"), PhotoImage(file
                        = "characterSprites/dsCharGifs/alert_0.gif"), PhotoImage(file = 
                            "characterSprites/djCharGifs/alert_0.gif")]
    data.screen = "startScreen"
    data.winner = None
    data.time = 300000 #can adjust timer accordingly
    data.setJumpTime = 1000
    data.bulletFireTime = 1000
    data.p1move = False
    data.p1moveCounter = data.timerDelay*2
    data.p2moveCounter = data.timerDelay*2
    data.p2move = False
    data.p1animation = 0
    data.p2animation = 0
    data.buffSprites = {"speed":PhotoImage(file = "buffSprites/speedUp.gif"), "slow":PhotoImage(file ="buffSprites/slow.gif"), 
    "shotgun":PhotoImage(file = "buffSprites/shotgun.gif"), "poison":PhotoImage(file = "buffSprites/healthLoss.gif"), 
        "healthRegen":PhotoImage(file = "buffSprites/heartSprite.gif")}
    bulletFire1(data, 1)
    bulletFire2(data, 1)
    setTimer(data, 1)
    monsterSpawnTimer(data)
    affectSpawnTimer(data)

def imageSet(player):
    if isinstance(player, Player):
        if isinstance(player, DoubleJump):
            fileList = listFiles("characterSprites/djCharGifs")
        if isinstance(player, DoubleAttack):
            fileList = listFiles("characterSprites/daCharGifs")
        if isinstance(player, DoubleSpeed):
            fileList = listFiles("characterSprites/dsCharGifs")
        if isinstance(player, DoubleHealth):
            fileList = listFiles("characterSprites/dhCharGifs")
        if len(fileList)!=0:
            for filename in fileList:
                if "R" in filename:
                    direction = "right"
                if "R" not in filename:
                    direction = "left"
                if "jump" in filename:
                    animation = "jump"
                if "stab" in filename:
                    animation = "shoot"
                if "alert" in filename:
                    animation = "alert"
                if "walk" in filename:
                    animation = "walk"
                index = int(filename[-5])
                player.images[direction][animation][index] = PhotoImage(file=filename)
    
def affectSpawnTimer(data):
    data.affectSp = 1000
    data.affectSC = 0

def monsterSpawnTimer(data):
    data.monsterSpawn = 1000
    data.monsterSC = 0    

def setTimer(data, seconds):
    data.p1Time = seconds*1000
    data.p1g = True
    data.p2Time = seconds*1000
    data.p2g = True

def playerInt(data):    
    data.g = 0.6 #gravity when the player jumps
    data.v1Down = 0
    data.v2Down = 0
    
def bulletFire1(data, seconds):
    data.p1baseFireTime = 1000//seconds
    data.p1FireTime = 1000
    data.p1Fire = False
    
def bulletFire2(data, seconds):
    data.p2baseFireTime = 1000//seconds
    data.p2FireTime = seconds*1000
    data.p2Fire = False

def startMethod(data):
    data.role1 = ""
    data.bullets1 = []
    data.bullets2 = []
    data.bulletsM = []
    data.monsters = []
    data.affects = []
    data.role2 = ""
    data.classes = {0:"Double Health", 1: "Double Attack", 2: "Double Speed", 3: "Double Jump"}
    data.colors = {0: "Red", 1: "Blue", 2: "Yellow", 3: "Green"}
    
def spawnPlayers(data):
    print("wow")
    if data.role1 == "Double Health":
        data.player1 = DoubleHealth("Up", "Left", "Right", "Down", data.pos1, True)
    if data.role1 == "Double Attack":
        data.player1 = DoubleAttack("Up", "Left", "Right", "Down", data.pos1, True)
    if data.role1 == "Double Speed":
        data.player1 = DoubleSpeed("Up", "Left", "Right", "Down", data.pos1, True)
    if data.role1 == "Double Jump":
        data.player1 = DoubleJump("Up", "Left", "Right", "Down", data.pos1, True)
        
    if data.role2 == "Double Health":
        data.player2 = DoubleHealth("w", "a", "d", "s", data.pos2, False)
    if data.role2 == "Double Attack":
        data.player2 = DoubleAttack("w", "a", "d", "s", data.pos2, False)
    if data.role2 == "Double Speed":
        data.player2 = DoubleSpeed("w", "a", "d", "s", data.pos2, False)
    if data.role2 == "Double Jump":
        data.player2 = DoubleJump("w", "a", "d", "s", data.pos2, False)
            
            

    
# data.screen is either: "startScreen" "howToScreen" "choosePlayer1", "choosePlayer2" "winScreen"

def mousePressed(event, data):
    if data.screen == "startScreen":
        if data.height*3/5-7.5<=event.y<=data.height*3/5+7.5:
            if data.width/2-60<=event.x<=data.width/2+60:
                data.screen = "choosePlayer1"
        if data.height*4/5-7.5<=event.y<=data.height*4/5+4.5:
            if data.width/2-60<=event.x<=data.width/2+60:
                data.screen = "howToScreen"
                    
    
    elif data.screen == "howToScreen":
        if 0<=event.x<=data.width:
            if 0<=event.y<=data.height:
                print("click")
                data.screen = "startScreen"
    
    elif data.screen == "choosePlayer1":
        for i in range(4):
            if data.width/8*(2*i+1)-30<event.x<data.width/8*(2*i+1)+30:
                if data.height/2-30<event.y<data.height/2+30:
                    data.role1 = data.classes[i]
                    print(data.role1)
                    data.screen = "choosePlayer2"
                    
    elif data.screen == "choosePlayer2":
        for i in range(4):
             if data.width/8*(2*i+1)-30<event.x<data.width/8*(2*i+1)+30:
                if data.height/2-30<event.y<data.height/2+30:
                    data.role2 = data.classes[i]
                    print(data.role2)
                    createStage0(data)
                    spawnPlayers(data)
                    imageSet(data.player1)
                    imageSet(data.player2)
                    data.screen = "stage"
    
    elif data.screen =="winScreen":
        if 0<event.x<data.width:
            if 0<event.y<data.height:
                init(data)

def twoPlayKeyInter(event, data):
    
    if event.keysym==data.player1.up:
        if data.player1.canJump():
            data.p1Time = data.setJumpTime
            data.player1.jumpMotion = True
            
    if event.keysym==data.player1.left:
        data.player1.lkLeft()
        data.player1.move(-data.player1.speed, 0)
        
        data.p1moveCounter = data.timerDelay*2
        
        for floor in data.floors:
            if floor.x1<data.player1.x1<=floor.x2 or floor.x1<=data.player1.x2<=floor.x2:
                if data.player1.y1<=floor.y1<=data.player1.y2:
                    data.player1.move(data.player1.speed, 0)
        
        for wall in data.walls:
            if data.player1.wallCollision(wall):
                data.player1.move(data.player1.speed, 0)
                

    
    if event.keysym==data.player1.right:
        data.player1.lkRight()
        data.player1.move(data.player1.speed, 0)
        
        data.p1moveCounter = data.timerDelay*2
        
        for floor in data.floors:
            if floor.x1<=data.player1.x1<=floor.x2 or floor.x1<=data.player1.x2<=floor.x2:
                if data.player1.y1<=floor.y1<=data.player1.y2:
                    data.player1.move(-data.player1.speed, 0)
        
        for wall in data.walls:
            if data.player1.wallCollision(wall):
                data.player1.move(-data.player1.speed, 0)
                
        
                

           
    
    if event.keysym==data.player1.fire:
        if data.p1FireTime%data.p1baseFireTime==0 and data.p1FireTime>0:
            data.p1Fire = True
            player1Cx = (data.player1.x1+data.player1.x2)//2
            player1Cy = (data.player1.y1+data.player1.y2)//2
            if data.player1.faceRight:
                data.player1.image = data.player1.images["right"]["shoot"][0]
                bulletPos = [1+data.player1.x2, player1Cy-2, 2+data.player1.x2, 2+player1Cy]
                data.bullets1+=[Bullet(bulletPos, [7,0], data.player1.damage)]
                print(data.player1.damage)
                if data.player1.affect == "shotgun":
                    data.bullets1+=[Bullet(bulletPos, [7**0.5, -(7**0.5)], data.player1.damage)]
                    data.bullets1+=[Bullet(bulletPos, [7**0.5, 7**0.5], data.player1.damage)]
            else:
                data.player1.image = data.player1.images["left"]["shoot"][0]
                bulletPos = [-1+data.player1.x1, player1Cy-2, -2+data.player1.x1, 2+player1Cy]
                data.bullets1+=[Bullet(bulletPos, [-7,0], data.player1.damage)]
                if data.player1.affect == "shotgun":
                    data.bullets1+=[Bullet(bulletPos, [-(7**0.5), -(7**0.5)], data.player1.damage)]
                    data.bullets1+=[Bullet(bulletPos, [-(7**0.5), 7**0.5], data.player1.damage)]
                    
    if event.keysym==data.player2.up:
        if data.player2.canJump():
            data.p2Time = data.setJumpTime
            data.player2.jumpMotion = True
    
    if event.keysym==data.player2.left:
        data.player2.lkLeft()
        data.player2.move(-data.player2.speed, 0)
        
        data.p2moveCounter = data.timerDelay*2

        for floor in data.floors:
            if floor.x1<=data.player2.x1<=floor.x2 or floor.x1<=data.player2.x2<=floor.x2:
                if data.player2.y1<=floor.y1<=data.player2.y2:
                    data.player2.move(data.player2.speed, 0)
                
        for wall in data.walls:
            if data.player2.wallCollision(wall):
                data.player2.move(data.player2.speed, 0)
                

    
    if event.keysym==data.player2.right:
        data.player2.lkRight()
        data.player2.move(data.player2.speed, 0)
        
        data.p2moveCounter = data.timerDelay*2
        
        for floor in data.floors:
            if floor.x1<=data.player2.x1<=floor.x2 or floor.x1<=data.player2.x2<=floor.x2:
                if data.player2.y1<=floor.y1<=data.player2.y2:
                    data.player2.move(-data.player2.speed, 0)
        
        for wall in data.walls:
            if data.player2.wallCollision(wall):
                data.player2.move(-data.player2.speed, 0)
                

        
                
    if event.keysym==data.player2.fire:
        if data.p2FireTime%data.p2baseFireTime==0 and data.p2FireTime>0:
            data.p2Fire = True
            player2Cx = (data.player2.x1+data.player2.x2)//2
            player2Cy = (data.player2.y1+data.player2.y2)//2
            if data.player2.faceRight:
                bulletPos = [1+data.player2.x2, player2Cy-2, 2+data.player2.x2, 2+player2Cy]
                data.bullets2+=[Bullet(bulletPos, [7,0], data.player2.damage)]
                if data.player2.affect == "shotgun":
                    data.bullets2+=[Bullet(bulletPos, [7**0.5, -(7**0.5)], data.player2.damage)]
                    data.bullets2+=[Bullet(bulletPos, [7**0.5, 7**0.5], data.player2.damage)]
            else:
                bulletPos = [-1+data.player2.x1, player2Cy-2, -2+data.player2.x1, player2Cy+2]
                data.bullets2+=[Bullet(bulletPos, [-7,0], data.player2.damage)]
                if data.player2.affect == "shotgun":
                    data.bullets2+=[Bullet(bulletPos, [-(7**0.5), -(7**0.5)], data.player2.damage)]
                    data.bullets2+=[Bullet(bulletPos, [-(7**0.5), 7**0.5], data.player2.damage)]
            
                
def keyPressed(event, data):
    # use event.char and event.keysym
    if event.keysym=="r":
        init(data)
    if event.keysym=="space":
        print(data.player1.health/data.player1.maxHealth)
    twoPlayKeyInter(event, data)
   
def winner(data):
    if data.player2.health<=0:
        data.winner = "player1"
        data.screen = "winScreen"
    elif data.player1.health<=0:
        data.winner = "player2"
        data.screen = "winScreen"
    elif data.player1.health>data.player2.health and data.time == 0:
        data.winner = "player1"
        data.screen = "winScreen"
    elif data.player1.health<data.player2.health and data.time == 0:
        data.winner = "player2"
        data.screen = "winScreen"
    elif data.player1.health == data.player2.health and data.time == 0:
        data.screen = "winScreen"    
        
            
def bulletMechanics(data):
    if data.p1Fire:
        data.p1FireTime-=data.timerDelay
    if data.p2Fire:
        data.p2FireTime-=data.timerDelay
    
    if data.p1FireTime<0:
        data.p1Fire = False
        data.p1FireTime = 1000
        
    if data.p2FireTime<0:
        data.p2Fire = False
        data.p2FireTime = 1000
            
    for bullet in data.bullets1:
        bullet.fired()
        
    for bullet in data.bullets2:
        bullet.fired()
        
    for bullet in data.bulletsM:
        bullet.fired()
    
    if len(data.bullets1)>0:
        for i in range(len(data.bullets1)-1, -1, -1):
            if data.player2.bulletCollision(data.bullets1[i]):
                data.player2.health-=data.bullets1[i].damage
                data.bullets1.pop(i)
                break
                
    if len(data.bullets2)>0:
        for i in range(len(data.bullets2)-1, -1, -1):
            if data.player1.bulletCollision(data.bullets2[i]):
                data.player1.health-=data.bullets2[i].damage
                data.bullets2.pop(i)
                break
                
    if len(data.bulletsM)>0:
        for i in range(len(data.bulletsM)-1, -1, -1):
            if data.player1.bulletCollision(data.bulletsM[i]):
                data.player1.health-=data.bulletsM[i].damage
                data.bulletsM.pop(i)
                break
            if data.player2.bulletCollision(data.bulletsM[i]):
                data.player2.health-=data.bulletsM[i].damage
                data.bulletsM.pop(i)
                break
                
    if len(data.bullets1)>0 and len(data.bullets2)>0:
        bulletPop = False
        for i in range(len(data.bullets1)-1, -1, -1):
            if bulletPop:
                break
            for j in range(len(data.bullets2)-1, -1, -1):
                if data.bullets2[j].bulletCollision(data.bullets1[i]):
                    data.bullets2.pop(j)
                    data.bullets1.pop(i)
                    bulletPop = True
                    break
                    
    if len(data.bullets1)>0 and len(data.bulletsM)>0:
        bulletPop = False
        for i in range(len(data.bullets1)-1, -1, -1):
            if bulletPop:
                break
            for j in range(len(data.bulletsM)-1, -1, -1):
                if data.bulletsM[j].bulletCollision(data.bullets1[i]):
                    data.bulletsM.pop(j)
                    data.bullets1.pop(i)
                    bulletPop = True
                    break
                    
    if len(data.bulletsM)>0 and len(data.bullets2)>0:
        bulletPop = False
        for i in range(len(data.bulletsM)-1, -1, -1):
            if bulletPop:
                break
            for j in range(len(data.bullets2)-1, -1, -1):
                if data.bullets2[j].bulletCollision(data.bulletsM[i]):
                    data.bullets2.pop(j)
                    data.bulletsM.pop(i)
                    bulletPop = True
                    break
                
    for i in range(len(data.bullets1)-1, -1, -1):
        bulletPop = False
        for floor in data.floors:
            if data.bullets1[i].floorCollision(floor):
                print("pop!")
                data.bullets1.pop(i)
                bulletPop = True
                break
        if bulletPop:
            break
            
        for wall in data.walls:
            if data.bullets1[i].wallCollision(wall):
                print("pop!")
                data.bullets1.pop(i)
                bulletPop = True
                break
        if bulletPop:
            break
                
    for i in range(len(data.bullets2)-1, -1, -1):
        bulletPop = False
        for floor in data.floors:
            if data.bullets2[i].floorCollision(floor):
                print("pop!")
                data.bullets2.pop(i)
                bulletPop = True
                break
                
        if bulletPop:
            break
                
        for wall in data.walls:
            if data.bullets2[i].wallCollision(wall):
                print("pop!")
                data.bullets2.pop(i)
                bulletPop = True
                break
        if bulletPop:
            break
            
    for i in range(len(data.bulletsM)-1, -1, -1):
        bulletPop = False
        for floor in data.floors:
            if data.bulletsM[i].floorCollision(floor):
                print("pop!")
                data.bulletsM.pop(i)
                bulletPop = True
                break
                
        if bulletPop:
            break
                
        for wall in data.walls:
            if data.bulletsM[i].wallCollision(wall):
                print("pop!")
                data.bulletsM.pop(i)
                bulletPop = True
                break
        if bulletPop:
            break

def playerCollideWall(data, player):
    if isinstance(player, Player):
        for wall in data.walls:
            if player.wallCollision(wall):
                return True
        return False

def playerCollideFloor(data, player):
    if isinstance(player, Player):
        for floor in data.floors:
            if player.floorCollision(floor):
                return True
        return False

def playerMechanics(data):
        data.p1moveCounter -= data.timerDelay
        if data.p1moveCounter<=0:
            data.p1move = False
        else:
            data.p1move = True
            
        player1Height = data.player1.y2-data.player1.y1
        
        if data.p1Fire and not data.p1move:
            if data.player1.faceRight:
                data.player1.image = data.player1.images["right"]["shoot"][0]
            else:
                data.player1.image = data.player1.images["left"]["shoot"][0]
                
        if data.player1.jumpMotion or data.p1g:
            if data.player1.faceRight and not data.p1Fire:
                data.player1.image=data.player1.images["right"]["jump"][0]
            if not data.player1.faceRight and not data.p1Fire:
                data.player1.image=data.player1.images["left"]["jump"][0]
                
        if not (data.player1.jumpMotion or data.p1g):
            if data.p1move:
                if data.player1.faceRight:
                    data.player1.image = data.player1.images["right"]["walk"][(data.p1animation//100)%4]
                else:
                    data.player1.image = data.player1.images["left"]["walk"][(data.p1animation//100)%4]
            elif not data.p1move and not data.p1Fire:
                if data.player1.faceRight:
                    data.player1.image = data.player1.images["right"]["alert"][(data.p1animation//500)%3]
                else:
                    data.player1.image = data.player1.images["left"]["alert"][(data.p1animation//500)%3]
        
        if data.player1.jumpMotion:
            data.p1g = False
            data.p1Time-=data.timerDelay
            data.player1.move(0, -data.p1Jump)
            for floor in data.floors:
                if data.player1.floorCollision(floor) and data.player1.y2>floor.y1:
                    data.player1.y1 = floor.y1+1
                    data.player1.y2 = data.player1.y1+player1Height
                    data.p1Time = 0
                    break
                    
        if data.p1Time<=0:
            data.player1.jumpMotion = False
            data.p1g= True
        
        if data.p1g:
            data.v1Down+=data.g
            data.player1.move(0, +data.v1Down)
            for floor in data.floors:
                if (data.player1.x1>=floor.x1 and data.player1.x1<=floor.x2) or (
                data.player1.x2>=floor.x1 and data.player1.x2<=floor.x2):
                    if data.player1.y2+data.v1Down>floor.y1>data.player1.y2:
                        data.player1.y2 = floor.y1-1
                        data.player1.y1 = data.player1.y2 - player1Height
                        data.player1.onTop()
                        break
                
        data.p2moveCounter -= data.timerDelay
        if data.p2moveCounter<=0:
            data.p2move = False
        else:
            data.p2move = True
            
        player2Height = data.player2.y2-data.player2.y1
        
        if data.p2Fire and not data.p2move:
            if data.player2.faceRight:
                data.player2.image = data.player2.images["right"]["shoot"][0]
            else:
                data.player2.image = data.player2.images["left"]["shoot"][0]
                
        if data.player2.jumpMotion or data.p2g:
            if data.player2.faceRight and not data.p2Fire:
                data.player2.image=data.player2.images["right"]["jump"][0]
            if not data.player2.faceRight and not data.p2Fire:
                data.player2.image=data.player2.images["left"]["jump"][0]
                
        if not (data.player2.jumpMotion or data.p2g):
            if data.p2move:
                if data.player2.faceRight:
                    data.player2.image = data.player2.images["right"]["walk"][(data.p1animation//100)%4]
                else:
                    data.player2.image = data.player2.images["left"]["walk"][(data.p1animation//100)%4]
            elif not data.p1move and not data.p1Fire:
                if data.player2.faceRight:
                    data.player2.image = data.player2.images["right"]["alert"][(data.p1animation//500)%3]
                else:
                    data.player2.image = data.player2.images["left"]["alert"][(data.p1animation//500)%3]
        
        if data.player2.jumpMotion:
            data.p2g = False
            data.p2Time-=data.timerDelay
            data.player2.move(0, -data.p2Jump)
            for floor in data.floors:
                if data.player2.floorCollision(floor) and data.player2.y2+1>floor.y1:
                    data.player2.y1 = floor.y1+1
                    data.player2.y2 = data.player2.y1+player2Height
                    data.p2Time = 0
                    break
                    
        if data.p2Time<=0:
            data.player2.jumpMotion = False
            data.p2g= True
        
        if data.p2g:
            data.v2Down+=data.g
            data.player2.move(0, +data.v2Down)
            for floor in data.floors:
                if (data.player2.x1>=floor.x1 and data.player2.x1<=floor.x2) or (
                data.player2.x2>=floor.x1 and data.player2.x2<=floor.x2):
                    if data.player2.y2+data.v2Down>floor.y1>data.player2.y2:
                        data.player2.y2 = floor.y1-1
                        data.player2.y1 = data.player2.y2 - player2Height
                        data.player2.onTop()
                        break
 
                        
        if playerCollideFloor(data, data.player1):
            data.p1g =  False
            data.player1.onTop()
            data.v1Down = 0 
            data.p1Time = data.setJumpTime
        
        if not playerCollideFloor(data, data.player1) and not data.player1.jumpMotion:
            data.p1g = True
                
        if playerCollideFloor(data, data.player2):
            data.p2g = False
            data.player2.onTop()
            data.v2Down = 0
            data.p2Time = data.setJumpTime
            
        if not playerCollideFloor(data, data.player2) and not data.player2.jumpMotion:
            data.p2g = True
        

def affectMechanics(data):
    data.affectSC+=data.timerDelay
    data.player1.affectCountDown(data.timerDelay)
    data.player2.affectCountDown(data.timerDelay)
    
    for i in range(len(data.affects)-1,-1,-1):
        data.affects[i].counter-=data.timerDelay
        if data.affects[i].counter<=0:
            data.affects.pop(i)
            break
            
    if data.affectSC>data.affectSp:
        data.affectSC = 0
        if random.choice(data.affectInt)==0:
            affect = random.choice(data.typeAffect)
            spawn = random.choice(data.affectSpawn)
            if affect == "speed":
                width=30
                height=26
            if affect == "slow":
                width=37
                height=25
            if affect == "shotgun":
                width=50
                height=10
            if affect == "poison":
                width=27
                height=40
            if affect == "healthRegen":
                width=35
                height=31
            type = Affect(affect, [spawn[0], spawn[1], spawn[0]+width, spawn[1]+height])
            type.image=data.buffSprites[affect]
            data.affects+=[type]
    
    for i in range(len(data.affects)-1, -1, -1):
        if data.player1.affectCollision(data.affects[i]):
            data.player1.affect = data.affects[i].type
            if data.player1.affect == "speed":
                data.player1.speed*=2
            if data.player1.affect == "slow":
                data.player1.speed//=2
            data.affects.pop(i)
            break
        if data.player2.affectCollision(data.affects[i]):
            data.player2.affect = data.affects[i].type
            if data.player2.affect == "slow":
                data.player2.speed//=2        
            if data.player2.affect == "speed":
                data.player2.speed*=2
            data.affects.pop(i)
            break
    
    if data.player1.affect == "healthRegen":
        if data.player1.affectCounter%1000==0:
            data.player1.health+=5
        if data.player1.health>=data.player1.maxHealth:
            data.player1.health = data.player1.maxHealth
            
    if data.player2.affect == "healthRegen":
        if data.player2.affectCounter%1000==0:
            data.player2.health+=5
        if data.player2.health>=data.player2.maxHealth:
            data.player2.health = data.player2.maxHealth
            
    if data.player1.affect == "poison":
        if data.player1.affectCounter%500==0:
            data.player1.health-=1
            
    if data.player2.affect == "poison":
        if data.player2.affectCounter%500==0:
            data.player2.health-=1
    
            
def monsterMechanics(data):
    data.monsterG = 0.8
    data.monsterSC+=data.timerDelay
    
    if data.player1.invincible:
        data.player1.invCounter-=data.timerDelay
        if data.player1.invCounter<=0:
            data.player1.invincible = False
            data.player1.invCounter = data.player1.baseInvCounter
        
                

    if data.player2.invincible:
        data.player2.invCounter-=data.timerDelay
        if data.player2.invCounter<=0:
            data.player2.invincible = False
            data.player2.invCounter = data.player2.baseInvCounter



    if data.monsterSC >= data.monsterSpawn:
        data.monsterSC = 0
        if random.choice(data.eSpawner) == 0:
            spawn = random.choice(data.baseMonSpawn)
            randomRole = random.randint(0,1)
            if len(data.monsters)<2:
                if randomRole == 0:
                    data.monsters+=[Monster([spawn[0], spawn[1], spawn[0]+64, spawn[1]+55])]
                else:
                    data.monsters+=[ProjectileMonster([spawn[0], spawn[1], spawn[0]+48, spawn[1]+45])]
            
        if random.choice(data.eSpawner) == 0:
            if len(data.monsters)<2:
                spawn = random.choice(data.flyMonSpawn)
                data.monsters+=[FlyingMonster([spawn[0], spawn[1], spawn[0]+46, spawn[1]+30])]
    
    for i in range(len(data.monsters)-1, -1, -1):
        if not data.monsters[i].isAlive():
            data.monsters.pop(i)
    
    for monster in data.monsters:
        if data.time%80==0:
            monster.index+=1
        
        if monster.faceRight:
            ind = len(monster.images["right"])
            monster.image = monster.images["right"][monster.index%ind]
        elif not monster.faceRight:
            ind = len(monster.images["left"])
            monster.image = monster.images["left"][monster.index%ind]
        
        monsterCx = (monster.x2+monster.x1)//2
        monsterCy = (monster.y2+monster.y1)//2
        player1Cx = (data.player1.x1+data.player1.x2)//2
        player1Cy = (data.player1.y1+data.player1.y2)//2
        player2Cx = (data.player2.x1+data.player2.x2)//2
        player2Cy = (data.player2.y1+data.player2.y2)//2
        
################################################################################  

        if data.player1.enemyCollision(monster):
            if not data.player1.invincible:
                data.player1.health-=monster.damage
                data.player1.invincible = True
                
        if data.player2.enemyCollision(monster):
            if not data.player2.invincible:
                data.player2.health-=monster.damage
                data.player2.invincible = True
        
        if monster.faceRight:
            monster.move(3, 0)
            
            for wall in data.walls:
                if monster.wallCollision(wall):
                    monster.faceRight = False
                    break
                    
        elif not monster.faceRight:
            monster.move(-3, 0)
            
            for wall in data.walls:
                if monster.wallCollision(wall):
                    monster.faceRight = True
                    break
        
        if abs(player1Cx-monsterCx)<abs(player2Cx-monsterCx) and abs(player1Cx-monsterCx)<200 and abs(
            player1Cy-monsterCy)<200:
            if player1Cx<monsterCx:
                monster.faceRight = False
            else:
                monster.faceRight = True
        
        if abs(player2Cx-monsterCx)<abs(player1Cx-monsterCx) and abs(player2Cx-monsterCx)<200 and abs(
            player2Cy-monsterCy)<200:
            if player2Cx<monsterCx:
                monster.faceRight = False
            else:
                monster.faceRight = True
            
        if not isinstance(monster, FlyingMonster):
            falling = True
            for floor in data.floors:
                if monster.floorCollision(floor):
                    falling = False
                    break
            if falling:
                monster.vDown+=data.monsterG
                monsterHeight = monster.y2-monster.y1
                for floor in data.floors:
                    if (monster.x1>floor.x1 and monster.x1<floor.x2) or (
                        monster.x2>floor.x1 and monster.x2<floor.x2):
                        if monster.y2+monster.vDown>floor.y1:
                            monster.y2 = floor.y1 
                            monster.y1 = monster.y2 - monsterHeight
                            break
                        else:
                            monster.move(0, monster.vDown)
                            break
                            
        if isinstance(monster, FlyingMonster):
            if abs(player1Cy-monsterCy)<abs(player2Cy-monsterCy) and abs(player1Cy-monsterCy)<200 and abs(
                player1Cx-monsterCx)<200:
                if player1Cy<monsterCy:
                    monster.up = -1
                else:
                    monster.up = 1
        
            elif abs(player2Cy-monsterCy)<abs(player1Cy-monsterCy) and abs(player2Cy-monsterCy)<200 and abs(
                player2Cx-monsterCx)<200:
                if player2Cy<monsterCy:
                    monster.up = -1
                else:
                    monster.up = 1
            
            else:
                monster.up = 0
                    
            if monster.up == 1:
                monster.move(0, 3)
            elif monster.up == -1:
                monster.move(0, -3)
                
        if isinstance(monster, ProjectileMonster):
            if not monster.fire:
                monster.fireTime-=data.timerDelay
            if monster.fireTime<=0:
                monster.fireTime = monster.BfireTime
                monster.fireTime = True
            if abs(player1Cx-monsterCx)<abs(player2Cx-monsterCx) and abs(player1Cx-monsterCx)<600 and abs(
                player1Cy-monsterCy)<80:
                    if player1Cx>monsterCx:
                        monster.faceRight = True
                    else:
                        monster.faceRight = False
                    if monster.fire:
                        if monster.faceRight:
                            bulletPos = [1+monster.x2, monsterCy-2, 2+monster.x2, 2+monsterCy]
                            data.bulletsM+=[Bullet(bulletPos, [7,0], monster.damage)]
                            monster.fire = False
                        else:
                            bulletPos = [1+monster.x1, monsterCy-2, 2+monster.x1, 2+monsterCy]
                            data.bulletsM+=[Bullet(bulletPos, [-7,0], monster.damage)]
                            monster.fire = False
            elif abs(player2Cx-monsterCx)<abs(player1Cx-monsterCx) and abs(player2Cx-monsterCx)<600 and abs(
                player2Cy-monsterCy)<80:
                    if player2Cx>monsterCx:
                        monster.faceRight = True
                    else:
                        monster.faceRight = False
                    if monster.fire:
                        if monster.faceRight:
                            bulletPos = [1+monster.x2, monsterCy-2, 2+monster.x2, 2+monsterCy]
                            data.bulletsM+=[Bullet(bulletPos, [7,0], monster.damage)]
                            monster.fire = False
                        else:
                            bulletPos = [1+monster.x1, monsterCy-2, 2+monster.x1, 2+monsterCy]
                            data.bulletsM+=[Bullet(bulletPos, [-7,0], monster.damage)]
                            monster.fire = False
################################################################################
            
        for i in range(len(data.bullets1)-1, -1, -1):
            if monster.bulletCollision(data.bullets1[i]):
                monster.health-=data.bullets1[i].damage
                data.bullets1.pop(i)
                break
                
        for i in range(len(data.bullets2)-1, -1, -1):
            if monster.bulletCollision(data.bullets2[i]):
                monster.health-=data.bullets2[i].damage
                data.bullets2.pop(i)
                break
        
                
def timerFired(data):
    if "stage" in data.screen:
        data.p1move = False
        data.time-=data.timerDelay
        data.p1animation+=data.timerDelay
        data.p2animation+=data.timerDelay
        winner(data)
        bulletMechanics(data)
        playerMechanics(data)
        monsterMechanics(data)
        affectMechanics(data)
        for wall in data.walls:
            if data.player1.wallCollision(wall):
                print("hitWall")
      

 
def start(canvas, data):
    canvas.create_image(data.width/2, data.height/2, image = data.backGround)

    canvas.create_text(data.width//2, data.height/4, text = "PVP Platform.Py", fill = "black", font = "Helvetica 26 bold")
    canvas.create_text(data.width/2, data.height*3/5, text = "Play Game!", fill = "black", font = "Helvetica 15 bold")
    canvas.create_text(data.width/2, data.height*4/5, text = "How to Play", fill = "black", font = "Helvetica 15 bold")
    
def howTo(canvas, data):
    line1 = "The goal is to try to eliminate each other by using your bullets to attack each other!"
    line2 = "Each player can pick a specific role that allows them to have an advantage."
    line3 = "There are enemies that will try to attack you as you try to eliminate each other. You are allowed to eliminate them."
    line4 = "You can pick up buffs that will enhance your gameplay, but there are debuffs as well. Avoid them!"
    line5 = "If one player loses all of their health, the other player wins."
    line6 = "But if time runs out, the player with the most health wins."
    line7 = "Click anywhere to go back."
    lines = [line1, line2, line3, line4, line5, line6, line7]
    canvas.create_image(data.width/2, data.height/2, image = data.backGround)
    for i in range(len(lines)):
        canvas.create_text(data.width/2, data.height*(2*i+1)/(2*len(lines)), text = lines[i], fill = "black", font = "Helvetica 10 bold")
    
def choosePlayer(canvas, data):
    canvas.create_image(data.width/2, data.height/2, image = data.backGround)
    for i in range(4):
        canvas.create_text(data.width/8*(2*i+1), data.height/2-45, text = data.classes[i],  fill = "black", font= "Helvetica 10 bold")
        canvas.create_image(data.width/8*(2*i+1), data.height/2, image = data.pImages[i])
    if data.screen == "choosePlayer1":
            canvas.create_text(data.width/2, 20, text = "Player 1, Choose!", fill = "black",font= "Helvetica 20 bold")
    elif data.screen == "choosePlayer2":
        canvas.create_text(data.width/2, 20, text = "Player 2, Choose!", fill = "black", font= "Helvetica 20 bold")
        
def gamePlayer(canvas, data):
    canvas.create_image(data.width/2, data.height/2, image = data.stage)
    for wall in data.walls:
        canvas.create_line(wall.x1, wall.y1, wall.x1, wall.y2, fill = "black", width = 3)
    for floor in data.floors:
        canvas.create_line(floor.x1, floor.y1, floor.x2, floor.y1, fill = "black", width = 3)
        
    if isinstance(data.player1, Player):
        player1Cx = (data.player1.x1+data.player1.x2)//2
        player1Cy = (data.player1.y1+data.player1.y2)//2
        if isinstance(data.player1, DoubleAttack):
            if data.player1.faceRight:
                canvas.create_image(data.player1.x1-3, data.player1.y1+6,  anchor= NW, image = data.player1.image)
            else:
                canvas.create_image(data.player1.x2+3, data.player1.y1+6, anchor = NE, image = data.player1.image)
        if isinstance(data.player1,  DoubleHealth):
            if data.player1.faceRight:
                canvas.create_image(data.player1.x1-3, data.player1.y2+5,  anchor= SW, image = data.player1.image)
            else:
                canvas.create_image(data.player1.x2+3, data.player1.y2+5, anchor = SE, image = data.player1.image)
                
        if isinstance(data.player1, DoubleSpeed):
            canvas.create_image(player1Cx, player1Cy, image = data.player1.image)

                
        if isinstance(data.player1, DoubleJump):
            canvas.create_image(player1Cx, player1Cy, image = data.player1.image)
            
    canvas.create_rectangle(data.player1.x1-45, data.player1.y1-40, data.player1.x2+45, data.player1.y1-20, fill = "red")
    widthHealth1 = data.player1.x2-data.player1.x1+90
    health1Bar = data.player1.x1-45+(widthHealth1)*(data.player1.health/data.player1.maxHealth)
    canvas.create_rectangle(data.player1.x1-45, data.player1.y1-40, health1Bar, data.player1.y1-20, fill = "green")
    canvas.create_text(player1Cx, data.player1.y1-30, text = "Player 1 Health: %d" %(data.player1.health), fill = "white", font = "Helevtica 10 bold")

                    
    if isinstance(data.player2, Player):
        player2Cx = (data.player2.x1+data.player2.x2)//2
        player2Cy = (data.player2.y1+data.player2.y2)//2
        if isinstance(data.player2, DoubleAttack):
            if data.player2.faceRight:
                canvas.create_image(data.player2.x1-3, data.player2.y1+6,  anchor= NW, image = data.player2.image)
            else:
                canvas.create_image(data.player2.x2+3, data.player2.y1+6, anchor = NE, image = data.player2.image)
        if isinstance(data.player2,  DoubleHealth):
            if data.player2.faceRight:
                canvas.create_image(data.player2.x1-3, data.player2.y2+5,  anchor= SW, image = data.player2.image)
            else:
                canvas.create_image(data.player2.x2+3, data.player2.y2+5, anchor = SE, image = data.player2.image)
                
        if isinstance(data.player2, DoubleSpeed):
            canvas.create_image(player2Cx, player2Cy, image = data.player2.image)

                
        if isinstance(data.player2, DoubleJump):
            canvas.create_image(player2Cx, player2Cy, image = data.player2.image)
            
    canvas.create_rectangle(data.player2.x1-45, data.player2.y1-40, data.player2.x2+45, data.player2.y1-20, fill = "red")
    widthHealth2 = data.player2.x2-data.player2.x1+90
    health2Bar = data.player2.x1-45+(widthHealth2)*(data.player2.health/data.player2.maxHealth)
    canvas.create_rectangle(data.player2.x1-45, data.player2.y1-40, health2Bar, data.player2.y1-20, fill = "green")
    canvas.create_text(player2Cx, data.player2.y1-30, text = "Player 2 Health: %d" %(data.player2.health), fill = "white", font = "Helevtica 10 bold")
        
        
        
        
    for monster in data.monsters:
        canvas.create_image(monster.x2, monster.y2, anchor = SE, image = monster.image)
    for affect in data.affects:
        canvas.create_image(affect.x2, affect.y2, anchor = SE, image = affect.image)
    if (data.time%60000)>10000:
        canvas.create_text(data.width/2, data.height/8, text = "Time: %d:%d" %(data.time//60000, (data.time%60000)//1000), fill = "black", font = "Helvetica 26 bold")
    else:
        canvas.create_text(data.width/2, data.height/8, text = "Time: %d:0%d" %(data.time//60000, (data.time%60000)//1000), fill = "black", font = "Helvetica 26 bold")
            

    for bullet in data.bullets1:
        canvas.create_oval(bullet.x1, bullet.y1, bullet.x2, bullet.y2, fill = "black", width = 1)
    for bullet in data.bullets2:
        canvas.create_oval(bullet.x1, bullet.y1, bullet.x2, bullet.y2, fill = "black", width = 1)
    for bullet in data.bulletsM:
        canvas.create_oval(bullet.x1, bullet.y1, bullet.x2, bullet.y2, fill = "black", width = 1)
        
def winPlayer(canvas, data):
    canvas.create_image(data.width/2, data.height/2, image = data.backGround)
    if data.winner == "player1":
        canvas.create_text(data.width/2, data.height/8, text = "Player 1 Wins!", fill = "black", font = "Helvetica 26 bold")
    elif data.winner == "player2":
        canvas.create_text(data.width/2, data.height/8, text = "Player 2 Wins!", fill = "black", font = "Helvetica 26 bold")
    else:
        canvas.create_text(data.width/2, data.height/8, text = "It's a Tie!", fill = "black", font = "Helvetica 26 bold")
    canvas.create_text(data.width/2, data.height*7/8, text = "Click anywhere to go back", fill = "black", font = "Helvetica 26 bold")
    
def redrawAll(canvas, data):
    if data.screen == "startScreen":
        start(canvas, data)
        
    if data.screen == "howToScreen":
         howTo(canvas, data)
    
    if "choosePlayer" in data.screen:
        choosePlayer(canvas, data)

    if data.screen == "stage":
        gamePlayer(canvas, data)
        
    if data.screen == "winScreen":
        winPlayer(canvas, data)
        
def createBox(data, x1, y1, x2, y2):
    data.walls+=[Wall(x1,y1,y2), Wall(x2, y1, y2)]
    data.floors+=[ Floor(x1, y2, x2), Floor(x1, y1, x2)]
            
#stage Values
def createStage0(data):
    data.pos1 = [3, 5, 48, 71] 
    data.faceRight1 = True
    data.pos2 = [data.width-48, 5, data.width-3, 71] 
    data.faceRight2 = False
    #
    data.walls = []
    data.floors = []
    createBox(data, 0, 0, data.width, data.height)

    createBox(data, 0, data.height*3//4+10, data.width//4, data.height*3//4+30)
    createBox(data, data.width*3//4, data.height*3//4+10, data.width, data.height*3//4+30)
    createBox(data, 0, data.height//3+40, data.width//4, data.height//3+20)
    createBox(data, data.width*3//4, data.height//3+20, data.width, data.height//3+40)
    createBox(data, data.width//3, data.height//2+40, data.width*2//3, data.height//2+60)
    data.eSpawner = range(10)
    data.baseMonSpawn = [[1, data.height-70], [data.width-65, data.height-70], [data.width/2, data.height/2]]
    data.flyMonSpawn = [[1, 40], [data.width-50, 40], [data.width/2, data.height/2]]
    data.affectInt = range(10)
    data.affectSpawn = [[10, data.height-40], [data.width-30, data.height-40], [data.width/2, data.height/2]]
    data.typeAffect = ["shotgun", "healthRegen", "poison", "speed", "slow"]
    print(data.floors)
    data.p1Jump = 7
    data.p2Jump = 7
    
####################################
# use the run function as-is
####################################

def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        canvas.create_rectangle(0, 0, data.width, data.height,
                                fill='white', width=0)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 40 # milliseconds
    root = Tk()
    init(data)
    # create the root and the canvas
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

run(1024, 591)