# Updated Animation Starter Code

from tkinter import *

####################################
# customize these functions
####################################

def init(data):
    data.x1 = 1
    data.y1 = 1
    data.x2 = 21
    data.y2 = 21
    data.vDown = 3
    data.g = 1.5
    data.move = 15
    data.airCounter = 0
    data.jumpMotion = False
    data.jumpCounter = 0
    data.maxJump = 4
    data.movement = True
    
def mousePressed(event, data):
    # use event.x and event.y
    pass

def keyPressed1(event, data):
    if event.keysym=="Up":
        if data.jumpCounter < data.maxJump:
            data.jumpMotion = True
            data.jumpCounter += 1
            
    if event.keysym=="Left":
        if data.x1>1:
            data.movement = True
            data.x1 -= data.move
            data.x2 -= data.move
            
    if event.keysym=="Right":
        if data.x2<data.width:
            data.movement = True
            data.x1 += data.move
            data.x2 += data.move
            
def keyPressed2(event, data):
    if event.keysym=="Up" and data.movement:
        if data.jumpCounter < data.maxJump:
            data.jumpMotion = True
            data.jumpCounter += 1
            

def timerFired(data):
    if data.y2<data.height-1: #if in the air
        print("something")
        data.vDown+=data.g
        if data.y2+data.vDown>data.height:
            height = data.y2-data.y1
            data.y2 = data.height -1
            data.y1 = data.y2-height
        else:
            data.y1+=data.vDown
            data.y2+=data.vDown
        print(data.airCounter)
        data.airCounter+=data.timerDelay
    
    elif data.y2==data.height-1:
        print("huh")
        data.vDown = 3
        data.jumpCounter = 0
        data.airCounter = 0
        
    else:
        data.yHeight = data.y2-data.y1
        data.y2 = data.height-1
        data.y1 = data.y2-data.yHeight
        
    if data.airCounter>500:
        data.jumpMotion = False
        
    if data.jumpMotion:
        print("I Jumped!")
        data.y1-= data.move*2
        data.y2-= data.move*2
        
def redrawAll(canvas, data):
    canvas.create_rectangle(data.x1, data.y1, data.x2, data.y2, fill = "red")

####################################
# use the run function as-is
####################################

def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        canvas.create_rectangle(0, 0, data.width, data.height,
                                fill='white', width=0)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper1(event, canvas, data):
        keyPressed1(event, data)
        redrawAllWrapper(canvas, data)
        
    def keyPressedWrapper2(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 50 # milliseconds
    root = Tk()
    init(data)
    # create the root and the canvas
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper1(event, canvas, data), lambda event: keyPressedWrapper2(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

run(1200, 600)