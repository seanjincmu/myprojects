#Wall Class
import math
import random
from tkinter import *
import os

################################Used from Recurion Part 2#######################
def listFiles(path):
    if (os.path.isdir(path) == False):
        # base case:  not a folder, but a file, so return singleton list with its path
        return [path]
    else:
        # recursive case: it's a folder, return list of all paths
        files = [ ]
        for filename in os.listdir(path):
            files += listFiles(path + "/" + filename)
        return files
        
                

from PIL import *

class Wall(object):
    def __init__(self, x1, y1, y2):
        self.x1 = x1
        self.y1 = y1
        self.y2 = y2
    def img(self):
        pass #input a specifc number depending on sprite
        
#Floor Class

class Floor(object):
    def __init__(self, x1, y1, x2):
        self.x1 = x1
        self.x2 = x2
        self.y1 = y1
        
    def img(self):
        pass #input a specific number depending on sprite
        
#Player Class
health = 100
speed = 4
damage = 5
bulletDelay = 100
maxJump = 1

                    
class Player(object):
    def __init__(self, up, left, right, fire, position, faceRight):
        self.up = up
        self.left = left
        self.right = right
        self.fire = fire
        self.x1 = position[0] #left side of obj
        self.y1 = position[1] #top side of obj
        self.x2 = position[2] #right side of obj
        self.y2 = position[3] #bottom side of obj
        self.maxJump = maxJump #maximum number of jumps
        self.jumpCount = 0
        self.maxHealth = health #maximum number of health
        self.health = self.maxHealth #current health
        self.baseSpeed = speed
        self.speed = self.baseSpeed #speed of the player
        self.damage = damage #damage the player does to a character
        self.faceRight = faceRight #if the character is facing right
        self.jumpMotion = False
        self.affect = None
        self.affectCounter = 10000
        self.invincible = False
        self.images = {"left":{"shoot":dict(), "jump":dict(), "walk":dict(), "alert":dict()}, "right":{"shoot":dict(), "jump":dict(), "walk":dict(), "alert":dict()}}
        self.image = None
        self.baseInvCounter = 1000
        self.invCounter = self.baseInvCounter
        self.invincible = False
        
    def canJump(self):
        if self.jumpCount<self.maxJump:
            self.jumpCount+=1
            return True
        else:
            return False
    
    def onTop(self):
        self.jumpCount = 0        
    
    def lkRight(self):
        self.faceRight = True
        
    def lkLeft(self):
        self.faceRight = False
        
    def wallCollision(self, other):
        if isinstance(other, Wall):
            if (self.y1>=other.y1 and self.y1<=other.y2) or (
                self.y2>=other.y1 and self.y2<=other.y2): 
            #check if they're at the same level
                if self.x1-1<=other.x1<=self.x2+1: 
                #check if the player object is colliding with the wall as it's based on x-axis
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
    
    def floorCollision(self, other):
        if isinstance(other, Floor):
            if (self.x1>=other.x1 and self.x1<=other.x2) or (
                self.x2>=other.x1 and self.x2<=other.x2):
                if self.y1-1<=other.y1<=self.y2+1:
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
    
    def onTopCollision(self, other): #if the other player is ontop of the user
        if isinstance(other, Player):
            if (self.x1>=other.x1 and self.x1<=other.x2) or (
                self.x2>=other.x1 and self.x2<=other.x2):
                if other.y2>=self.y1:
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
    
    def leftCollision(self, other): #if the other player is colliding onto the left of the user
        if isinstance(other, Player):
            if (self.y1>=other.y1 and self.y1<=other.y2) or (
            self.y2>=other.y1 and self.y2<=other.y2):
                if other.x2>=self.x1:
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
    
    def rightCollision(self, other): #if the other player is colliding onto the right of the user
        if isinstance(other, Player):
            if (self.y1>=other.y1 and self.y1<=other.y2) or (
            self.y2>=other.y1 and self.y2<=other.y2):
                if other.x1<=self.x2:
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
    
    def affectCollision(self, other):
        if isinstance(other, Affect):
            if (other.y1>=self.y1 and other.y1<=self.y2) or (
            other.y2>=self.y1 and other.y2<=self.y2):
                if (other.x1>=self.x1 and other.x1<=self.x2) or (
                other.x2>=self.x1 and other.x2<=self.x2):
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
        
    def enemyCollision(self, other):
        if isinstance(other, Monster):
            if (other.y1>=self.y1 and other.y1<=self.y2) or (
            other.y2>=self.y1 and other.y2<=self.y2):
                if (other.x1>=self.x1 and other.x1<=self.x2) or (
                other.x2>=self.x1 and other.x2<=self.x2):
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False

    def affectCountDown(self, timer):
        if self.affect != None:
            self.affectCounter-=timer
            if self.affectCounter<=0:
                if self.affect == "speed" or self.affect == "slow":
                    self.resetSpeed()
                self.affect = None
                self.resetCount()
                
    def resetCount(self):
        self.affectCounter = 10000
            
    def bulletCollision(self, other):
        if isinstance(other, Bullet):
            if (other.y1>=self.y1 and other.y1<=self.y2) or (
            other.y2>=self.y1 and other.y2<=self.y2):
                if (other.x1>=self.x1 and other.x1<=self.x2) or (
                other.x2>=self.x1 and other.x2<=self.x2):
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
    
    def move(self, x, y):
        self.x1+=x
        self.y1+=y
        self.x2+=x
        self.y2+=y
    
    def resetSpeed(self):
        self.speed = self.baseSpeed


class DoubleJump(Player): #this player should be able to double jump
    def __init__(self, up, left, right, fire, position, faceRight):
        super().__init__(up, left, right, fire, position, faceRight)
        self.maxJump = maxJump*2
        self.jumpCount = 0
        self.maxHealth = health #maximum number of health
        self.health = self.maxHealth #current health
        self.baseSpeed = speed
        self.speed = self.baseSpeed
        self.damage = damage
        self.jumpMotion = False
        self.affect = None
        self.affectCounter = 10000
        self.images = {"left":{"shoot":dict(), "jump":dict(), "walk":dict(), "alert":dict()}, "right":{"shoot":dict(), "jump":dict(), "walk":dict(), "alert":dict()}}
        self.image = None
        self.baseInvCounter = 1000
        self.invCounter = self.baseInvCounter
        self.invincible = False
    
    def img(self):
        pass
        
class DoubleSpeed(Player): #this player should be going twice as fast
    def __init__(self, up, left, right, fire, position, faceRight):
        super().__init__(up, left, right, fire, position, faceRight)
        self.maxJump = maxJump
        self.jumpCount = 0
        self.maxHealth = health #maximum number of health
        self.health = self.maxHealth #current health
        self.baseSpeed = speed*2
        self.speed = self.baseSpeed
        self.damage = damage
        self.jumpMotion = False
        self.affect = None
        self.affectCounter = 10000
        self.images = {"left":{"shoot":dict(), "jump":dict(), "walk":dict(), "alert":dict()}, "right":{"shoot":dict(), "jump":dict(), "walk":dict(), "alert":dict()}}
        self.image = None
        self.baseInvCounter = 1000
        self.invCounter = self.baseInvCounter
        self.invincible = False
        
    def img(self):
        pass 
        
class DoubleAttack(Player): #does double damage to characters
    def __init__(self, up, left, right, fire, position, faceRight):
        super().__init__(up, left, right, fire, position, faceRight)
        self.maxJump = maxJump
        self.jumpCount = 0
        self.maxHealth = health #maximum number of health
        self.health = self.maxHealth #current health
        self.baseSpeed = speed
        self.speed = self.baseSpeed
        self.damage = damage*2
        self.jumpMotion = False
        self.affect = None
        self.affectCounter = 10000
        self.images = {"left":{"shoot":dict(), "jump":dict(), "walk":dict(), "alert":dict()}, "right":{"shoot":dict(), "jump":dict(), "walk":dict(), "alert":dict()}}
        self.image = None
        self.baseInvCounter = 1000
        self.invCounter = self.baseInvCounter
        self.invincible = False
        
    
    def img(self):
        pass
        
class DoubleHealth(Player): #has double the health of the characters
    def __init__(self, up, left, right, fire, position, faceRight):
        super().__init__(up, left, right, fire, position, faceRight)
        self.maxJump = maxJump
        self.jumpCount = 0
        self.maxHealth = health*2 #maximum number of health
        self.health = self.maxHealth #current health
        self.baseSpeed = speed
        self.speed = self.baseSpeed
        self.damage = damage
        self.jumpMotion = False
        self.affect = None
        self.affectCounter = 10000
        self.images = {"left":{"shoot":dict(), "jump":dict(), "walk":dict(), "alert":dict()}, "right":{"shoot":dict(), "jump":dict(), "walk":dict(), "alert":dict()}}
        self.image = None
        self.baseInvCounter = 1000
        self.invCounter = self.baseInvCounter
        self.invincible = False
        
    def img(self):
        pass
        
#Monster Class

class Monster(object): #affected by gravity
    def __init__(self, position):
        self.faceRight = random.choice([True, False]) #face/move right
        self.maxHealth = 20 #maximum number of health
        self.health = self.maxHealth #current health
        self.vDown = 0
        self.damage = damage
        self.grav = True #affected by gravity
        self.x1 = position[0]
        self.y1 = position[1]
        self.x2 = position[2]
        self.y2 = position[3]
        self.image = None
        self.images = {"left": {0:PhotoImage(file="enemySprites/monGifs/mush_0.gif"),1:PhotoImage(file = "enemySprites/monGifs/mush_1.gif"), 2:PhotoImage(file = "enemySprites/monGifs/mush_2.gif")}, "right": {0:PhotoImage(file ="enemySprites/monGifs/mushR_0.gif"), 1: PhotoImage(file = "enemySprites/monGifs/mushR_1.gif"),2: PhotoImage(file = "enemySprites/monGifs/mushR_2.gif")}}
        self.index = 0
        
        
    def wallCollision(self, other):
        if isinstance(other, Wall):
            if (self.y1>=other.y1 and self.y1<=other.y2) or (
                self.y2>=other.y1 and self.y2<=other.y2): 
            #check if they're at the same level
                if self.x1-1<=other.x1<=self.x2+1: 
                #check if the player object is colliding with the wall as it's based on x-axis
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
    
    def floorCollision(self, other):
        if isinstance(other, Floor):
            if (self.x1>=other.x1 and self.x1<=other.x2) or (
                self.x2>=other.x1 and self.x2<=other.x2):
                if self.y1-1<=other.y1<=self.y2+1:
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
    
            
    def bulletCollision(self, other):
        if isinstance(other, Bullet):
            if (other.y1>=self.y1 and other.y1<=self.y2) or (
            other.y2>=self.y1 and other.y2<=self.y2):
                if (other.x1>=self.x1 and other.x1<=self.x2) or (
                other.x2>=self.x1 and other.x2<=self.x2):
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
    
    def move(self, x, y):
        self.x1+=x
        self.x2+=x
        self.y1+=y
        self.y2+=y
    
    def isAlive(self):
        if self.health>0:
            return True
        else:
            return False
    
class FlyingMonster(Monster): 
    #not affected by gravity
    def __init__(self, position):
        super().__init__(position)
        self.faceRight = random.choice([True, False]) #face right
        self.maxHealth = 20 #maximum number of health
        self.health = self.maxHealth #current health
        self.damage = damage
        self.up = 0
        self.images = {"left": {0:PhotoImage(file ="enemySprites/flyingGifs/bat_0.gif"),1:PhotoImage(file = "enemySprites/flyingGifs/bat_1.gif")}, "right": {0:PhotoImage(file ="enemySprites/flyingGifs/batR_0.gif"), 1: PhotoImage(file = "enemySprites/flyingGifs/batR_1.gif")}}
        self.image = None
        self.index = 0
    
class ProjectileMonster(Monster):
    def __init__(self, position):
        super().__init__(position)
        self.faceRight = random.choice([True, False]) #face right
        self.maxHealth = 20 #maximum number of health
        self.health = self.maxHealth #current health
        self.damage = damage
        self.vDown = 0
        self.fire = True
        self.BfireTime = 1000
        self.fireTime = self.BfireTime
        self.images = {"left": {0:PhotoImage(file ="enemySprites/projGifs/squid_0.gif"),1:PhotoImage(file = "enemySprites/projGifs/squid_1.gif"), 2:PhotoImage(file ="enemySprites/projGifs/squid_2.gif"), 3:PhotoImage(file = "enemySprites/projGifs/squid_3.gif"), 4:PhotoImage(file = "enemySprites/projGifs/squid_4.gif")}, "right": {0:PhotoImage(file ="enemySprites/projGifs/squidR_0.gif"),1:PhotoImage(file = "enemySprites/projGifs/squidR_1.gif"), 2:PhotoImage(file ="enemySprites/projGifs/squidR_2.gif"), 3:PhotoImage(file = "enemySprites/projGifs/squidR_3.gif"), 4:PhotoImage(file = "enemySprites/projGifs/squidR_4.gif")}}
        self.image = None
        self.index = 0
    
    
#Affects Class


class Affect(object):
    def __init__(self, type, pos):
        self.type = type
        self.x1 = pos[0]
        self.y1 = pos[1]
        self.x2 = pos[2]
        self.y2 = pos[3]
        self.image = None
        self.counter = 15000
        
    
#Projectile Class

class Bullet(object):    
    def __init__(self, pos, speed, damage):
        self.x1 = pos[0]
        self.y1 = pos[1]
        self.x2 = pos[2]
        self.y2 = pos[3]
        self.damage = damage
        self.speed = speed
        self.path = ""
    
    def fired(self):
        self.x1+=self.speed[0]
        self.y1+=self.speed[1]
        self.x2+=self.speed[0]
        self.y2+=self.speed[1]
        
    def bulletCollision(self, other):
        if isinstance(other, Bullet):
            if self.y1>=other.y1 and self.y2<=other.y2:
                if self.x1>=other.x1 and self.x2<=other.x2:
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False

    def wallCollision(self, other):
        if isinstance(other, Wall):
            if (self.y1>other.y1 and self.y1<other.y2) or (
                self.y2>other.y2 and self.y2<other.y2): 
            #check if they're at the same level
                if self.x1<=other.x1<=self.x2: 
                #check if the player object is colliding with the wall as it's based on x-axis
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
            
    def floorCollision(self, other):
        if isinstance(other, Floor):
            if (self.x1>other.x1 and self.x1<other.x2) or (
                self.x2>other.x2 and self.x2<other.x2): 
            #check if they're at the same level
                if self.y1<=other.y1<=self.y2: 
                #check if the player object is colliding with the wall as it's based on x-axis
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False
    
