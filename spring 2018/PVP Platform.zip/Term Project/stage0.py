from tkinter import *
from playerClass import *
import random

    
def createStage(data):
    data.pos1 = [7, data.height-7, 12, data.height-2] 
    data.faceRight1 = True
    data.pos2 = [data.width-7, data.height-7, data.width-2, data.height-2] 
    data.faceRight2 = False
    #
    data.walls = [Wall(1, 1, data.width-1, data.height-1, 0)]
    data.floors = [Floor(1, 1, data.width-1, data.height-1, 0)]
    #
    data.eSpawner = random.randint(1, data.width)
