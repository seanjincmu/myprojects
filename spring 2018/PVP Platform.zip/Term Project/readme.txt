1. Open up the file "PVPPlayer.py"
2. Run the python file.
3. Enjoy the game!
4. Note that no additional libaries are needed as all the libraries needed for this TP has already been implemented.
5. DO NOT MIX UP THE SPIRTE FOLDERS! IT WILL CRASH THE "PVPPlayer.py" AND WILL NOT RUN!